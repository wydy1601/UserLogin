    /**
     * express接收html传递的参数
     */
     var  name
     var  userid
     var  password
     var  express=require('express');
     var  bodyParser = require('body-parser')
     var  app=express();
     var mysql=require('mysql');
     app.set('view engine', 'jade'); 
     app.set('views', __dirname);
     app.use(bodyParser.urlencoded({extended: false}))
     app.use(bodyParser.json())
 
     /**
      * 配置MySQL
      */
     var connection = mysql.createConnection({
         host     : '127.0.0.1',
         user     : 'root',
         password : 'hadoop',
         database : 'movierecommend',
         port:'3306'
     });
     connection.connect();
 
    /**
      * 跳转到网站首页，也就是用户登录页面
      */
     app.get('/',function (req,res) {
         res.render('index');
     })
 
     /**
      * 实现登录验证功能
      */
     app.post('/login',function (req,res) {
         name=req.body.username.trim();
         pwd=req.body.pwd.trim();
     console.log('username:'+name+'password:'+pwd);
 
         var selectSQL = "select * from user where username = '"+name+"' and password = '"+pwd+"'";
         connection.query(selectSQL,function (err,rs) {
             if (err) throw  err;
                         if (rs.length==0){
                 res.render('error',{title:'WARNING',message:'对不起，用户名：'+name+ ' 不存在'});
                 return;
                                 }
             rs = rs[0]
             userid = rs['userid']
             name = rs['username']
             password = rs['password']
             console.log(rs);
             console.log('ok');
             res.render('ok',{title:'Welcome User',message:name});
         })
     })
 
     /**
      * 跳转到注册页面
      */     
     app.get('/registerpage',function (req,res) {
       res.render('registerpage',{title:'注册'});
     })
 
     /**
      * 实现注册功能
      */
     app.post('/register',function (req,res) {
         var  name=req.body.username.trim();
        /*  console.log(name);*/
         var  pwd=req.body.pwd.trim();
         var  user={username:name,password:pwd};
         console.log(name,pwd,user);
         connection.query('insert into user set ?',user,function (err,rs) {
            if (err){
                throw err;
             }
            console.log('ok');
            res.render('ok',{title:'Welcome User',message:name});
         })
     })
     /**
      * 跳转到评分页面
      */     
     app.get('/ratingpage',function (req,res) {
       res.render('ratingpage',{title:'评分'});
     })
 
     /**
      * 实现评分功能
      */
     app.post('/rating',function (req,res) {
         var selectSQL = "select * from movieinfo" ;
         connection.query(selectSQL,function (err,rs) {
             if (err) throw  err;
                         if (rs.length==0){
                 res.render('error',{title:'WARNING',message:'对不起，数据库中没有任何电影'});
                 return;
                                 }
             var all_data = new Array();
             for (var i=0; i<5; i++) {
                 var data = '';
                 var result = rs[i];
                 data += 'id:' + result['movieid'] + ' name:' + result['moviename'] + ' time:' + result['releasetime'] + ' director:' + result['director'] + ' actor:' + result['leadactors'] + ' rating:' + result['averating'] + ' description:' + result['description'] + 'typelist' + result['typelist'] + '\n';
                 all_data.push(data)
             }
             console.log(all_data);
             res.render('ratingpage',{title:'电影信息',message5:all_data[4],message4:all_data[3],message3:all_data[2],message2:all_data[1],message1:all_data[0]});
         })
     })
 
     var  server=app.listen(3000,function () {
         console.log("userloginjade server start......");
     })
